# May tinh Perl. Nhap: 12 * 3 | 7 % 3 | 2 ^ 10 | sqrt 81 | q de thoat
use strict; use warnings;
while (1) {
  print "> "; my $l = <STDIN>; last unless defined $l; $l =~ s/^\s+|\s+$//g; last if $l eq 'q';
  my @p = split /\s+/, $l; my $r;
  if (@p == 2 && $p[0] eq 'sqrt' && $p[1] =~ /^-?\d+(\.\d+)?$/) { if ($p[1] < 0) { print "Ket qua khong xac dinh\n"; next } $r = sqrt($p[1]) }
  elsif (@p == 3 && $p[0] =~ /^-?\d+(\.\d+)?$/ && $p[2] =~ /^-?\d+(\.\d+)?$/) {
    my ($a, $o, $b) = @p;
    if ($o eq '+') { $r = $a + $b } elsif ($o eq '-') { $r = $a - $b } elsif ($o eq '*') { $r = $a * $b }
    elsif ($o eq '/' || $o eq '%') { if ($b == 0) { print "Loi: chia cho 0\n"; next } $r = $o eq '/' ? $a / $b : $a - $b * int($a / $b) }
    elsif ($o eq '^') { $r = $a ** $b } else { print "Toan tu khong ho tro\n"; next }
  } else { print "Cu phap: a op b | sqrt a\n"; next }
  printf "= %.12g\n", $r;
}
