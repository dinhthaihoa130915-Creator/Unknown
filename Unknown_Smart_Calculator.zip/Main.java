// May tinh Java. Nhap: 12 * 3 | 7 % 3 | 2 ^ 10 | sqrt 81 | q de thoat
import java.math.BigDecimal;
import java.util.Scanner;
public class Main {
  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    while (true) {
      System.out.print("> ");
      if (!s.hasNextLine()) return;
      String[] p = s.nextLine().trim().split("\\s+");
      if (p[0].equals("q")) return;
      double r;
      try {
        if (p.length == 2 && p[0].equals("sqrt")) r = Math.sqrt(Double.parseDouble(p[1]));
        else if (p.length == 3) {
          double a = Double.parseDouble(p[0]), b = Double.parseDouble(p[2]);
          switch (p[1]) {
            case "+": r = a + b; break; case "-": r = a - b; break; case "*": r = a * b; break;
            case "/": if (b == 0) { System.out.println("Loi: chia cho 0"); continue; } r = a / b; break;
            case "%": r = a % b; break; case "^": r = Math.pow(a, b); break;
            default: System.out.println("Toan tu khong ho tro"); continue;
          }
        } else { System.out.println("Cu phap: a op b | sqrt a"); continue; }
      } catch (NumberFormatException e) { System.out.println("So khong hop le"); continue; }
      if (Double.isNaN(r) || Double.isInfinite(r)) System.out.println("Ket qua khong xac dinh");
      else System.out.println("= " + new BigDecimal(r).round(new java.math.MathContext(12)).stripTrailingZeros().toPlainString());
    }
  }
}
