// May tinh C# (dotnet new console, thay Program.cs, dotnet run). Nhap: 12 * 3 | 7 % 3 | 2 ^ 10 | sqrt 81 | q
using System;
using System.Globalization;
static string Calc(string line)
{
    var p = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
    double r;
    bool N(string s, out double d) => double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out d);
    if (p.Length == 2 && p[0] == "sqrt" && N(p[1], out var x)) r = Math.Sqrt(x);
    else if (p.Length == 3 && N(p[0], out var a) && N(p[2], out var b))
    {
        switch (p[1])
        {
            case "+": r = a + b; break; case "-": r = a - b; break; case "*": r = a * b; break;
            case "/": if (b == 0) return "Loi: chia cho 0"; r = a / b; break;
            case "%": if (b == 0) return "Loi: chia cho 0"; r = a % b; break;
            case "^": r = Math.Pow(a, b); break;
            default: return "Toan tu khong ho tro";
        }
    }
    else return "Cu phap: a op b | sqrt a";
    return double.IsFinite(r) ? "= " + r.ToString("G12", CultureInfo.InvariantCulture) : "Ket qua khong xac dinh";
}
while (true)
{
    Console.Write("> ");
    var l = Console.ReadLine();
    if (l == null || l.Trim() == "q") break;
    Console.WriteLine(Calc(l));
}
