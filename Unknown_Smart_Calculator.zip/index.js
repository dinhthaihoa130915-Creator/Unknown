(() => {
"use strict";
const $ = id => document.getElementById(id);
let deg = true;

/* ===== Engine: biểu thức, biến, hàm, %, giai thừa, nhân ngầm ===== */
const FN = {
  sin: x => Math.sin(deg ? x*Math.PI/180 : x), cos: x => Math.cos(deg ? x*Math.PI/180 : x), tan: x => Math.tan(deg ? x*Math.PI/180 : x),
  asin: x => Math.asin(x)*(deg?180/Math.PI:1), acos: x => Math.acos(x)*(deg?180/Math.PI:1), atan: x => Math.atan(x)*(deg?180/Math.PI:1),
  sqrt: Math.sqrt, cbrt: Math.cbrt, log: Math.log10, ln: Math.log, abs: Math.abs, exp: Math.exp,
  floor: Math.floor, ceil: Math.ceil, round: Math.round, min: Math.min, max: Math.max, pow: Math.pow, mod: (a,b) => a % b,
  fact: n => { if (n < 0 || !Number.isInteger(n) || n > 170) throw Error("fact"); let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; }
};
const CONST = { pi: Math.PI, e: Math.E, tau: 2*Math.PI };

function tokenize(s) {
  s = s.replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹⁻]+/g, m => "^(" + [...m].map(c => c === "⁻" ? "-" : "⁰¹²³⁴⁵⁶⁷⁸⁹".indexOf(c)).join("") + ")").replace(/×/g,"*").replace(/÷/g,"/").replace(/−/g,"-").replace(/π/g,"pi").replace(/√/g,"sqrt");
  const re = /\s*(?:(\d+(?:\.\d*)?(?:e[+-]?\d+)?|\.\d+)|([\p{L}_][\p{L}\p{N}_]*)|([-+*\/^()%!,]))/uy, out = [];
  let i = 0;
  while (i < s.length) {
    if (/^\s*$/.test(s.slice(i))) break;
    re.lastIndex = i; const m = re.exec(s);
    if (!m) throw Error("Ký tự không hợp lệ");
    out.push(m[1] !== undefined ? {t:"n", v:+m[1]} : m[2] ? {t:"i", v:m[2].toLowerCase()} : {t:m[3]});
    i = re.lastIndex;
  }
  const r = [];
  for (const b of out) {
    const a = r[r.length-1];
    const end = a && (a.t==="n" || a.t===")" || a.t==="!" || a.t==="%" || (a.t==="i" && !(a.v in FN)));
    if (end && (b.t==="n" || b.t==="(" || b.t==="i")) r.push({t:"*"});
    r.push(b);
  }
  return r;
}

function evaluate(src, vars = {}) {
  const ts = tokenize(src); let p = 0, pct = false;
  const pk = () => ts[p], tk = () => ts[p++];
  const need = c => { if (!pk() || tk().t !== c) throw Error("Thiếu " + c); };
  function prim() {
    const t = tk(); if (!t) throw Error("Chưa hoàn chỉnh");
    if (t.t === "n") return t.v;
    if (t.t === "(") { const x = add(); need(")"); return x; }
    if (t.t === "i") {
      if (t.v in FN) { need("("); const a = [add()]; while (pk() && pk().t === ",") { tk(); a.push(add()); } need(")"); return FN[t.v](...a); }
      if (t.v in vars) return vars[t.v];
      if (t.v in CONST) return CONST[t.v];
      throw Error("Chưa biết: " + t.v);
    }
    throw Error("Sai cú pháp");
  }
  function post() {
    let x = prim();
    while (pk() && (pk().t === "!" || pk().t === "%")) { if (tk().t === "!") x = FN.fact(x); else { x /= 100; pct = true; } }
    return x;
  }
  function pow() { const x = post(); if (pk() && pk().t === "^") { tk(); pct = false; return Math.pow(x, un()); } return x; }
  function un() { if (pk() && pk().t === "-") { tk(); return -un(); } if (pk() && pk().t === "+") { tk(); return un(); } return pow(); }
  function mul() {
    let x = un();
    while (pk() && (pk().t === "*" || pk().t === "/")) { const o = tk().t, y = un(); pct = false; x = o === "*" ? x*y : x/y; }
    return x;
  }
  function add() {
    let x = mul();
    while (pk() && (pk().t === "+" || pk().t === "-")) {
      const o = tk().t; pct = false; let y = mul();
      if (pct) y = x*y;               // 100 + 10% = 110 (giống iPhone)
      x = o === "+" ? x+y : x-y;
    }
    return x;
  }
  if (!ts.length) throw Error("Trống");
  const v = add(); if (p !== ts.length) throw Error("Thừa ký tự");
  if (v === Infinity) throw Error("Vô hạn"); if (v === -Infinity) throw Error("-Vô hạn"); if (Number.isNaN(v)) throw Error("Không xác định");
  return v;
}

function fmt(n) {
  if (Object.is(n,-0)) n = 0;
  if (Math.abs(n) >= 1e15 || (n !== 0 && Math.abs(n) < 1e-9)) return n.toExponential(6).replace(/\.?0+e/, "e");
  return (+n.toPrecision(12)).toLocaleString("en-US", {maximumFractionDigits: 10});
}

/* ===== Tab Ghi chú (giống Math Notes của iPhone) ===== */
const ta = $("ta"), out = $("out"), nl = $("nlist");
let S = { cur: 0, notes: [{ text: "# Chi tiêu tháng\nLương = 15000000\nThuê nhà = 4500000\nĂn uống = 3 * 1200000\nLương - Thuê nhà - Ăn uống\n\nThuế 10% của lương\nLương * 10%\n100 + 10%\nsqrt(81) + 2^3\nsin(30)" }] };
try { const j = JSON.parse(localStorage.getItem("ucn") || "null"); if (j && j.notes && j.notes.length) S = j; } catch {}
const save = () => { try { localStorage.setItem("ucn", JSON.stringify(S)); } catch {} };
let results = [];

// Tên biến nhiều chữ ("Thuê nhà") -> thay bằng dạng thue_nha trước khi tính
const subst = (t, vars) => Object.keys(vars).filter(k => k.includes("_")).sort((a, b) => b.length - a.length)
  .reduce((t, k) => t.replace(new RegExp("(?<![\\p{L}\\p{N}_])" + k.replace(/_/g, "\\s+") + "(?![\\p{L}\\p{N}_])", "giu"), k), t);
function runNote() {
  const vars = {}; let last; results = [];
  const esc = s => s.replace(/[&<>]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
  out.innerHTML = ta.value.split("\n").map(line => {
    let l = line.trim(), r = "", html = "";
    if (l && !/^(#|\/\/)/.test(l)) {
      const eq = /=\s*$/.test(l); l = l.replace(/=\s*$/, "");
      const m = l.match(/^([\p{L}_][\p{L}\p{N}_ ]*?)\s*=\s*(.+)$/u);
      try {
        const v = evaluate(subst(m ? m[2] : l, vars), { ...vars, ans: last ?? 0 });
        if (m) vars[m[1].trim().toLowerCase().replace(/\s+/g, "_")] = v;
        last = v; r = fmt(v); html = esc(r);
      } catch (e) { if (eq || /^[\d(.]/.test(l)) html = '<span class="e">' + esc(e.message) + "</span>"; }
    }
    results.push(r); return html;
  }).join("\n");
  out.scrollTop = ta.scrollTop;
}
const first = n => n.text.split("\n")[0].replace(/^#\s*/, "").trim();
const nameOf = n => (n.title || first(n) || "Ghi chú mới");
function drawList() {
  $("ttl").placeholder = first(S.notes[S.cur]) || "Tiêu đề";
  nl.innerHTML = "";
  S.notes.forEach((n, i) => {
    const b = document.createElement("button"); b.className = i === S.cur ? "on" : "";
    b.textContent = nameOf(n).slice(0, 24);
    b.onclick = () => { S.cur = i; load(); }; b.oncontextmenu = e => { e.preventDefault(); if (S.notes.length > 1 && confirm("Xóa ghi chú này?")) { S.notes.splice(i,1); S.cur = 0; save(); load(); } };
    nl.append(b);
  });
  const a = document.createElement("button"); a.className = "add"; a.textContent = "＋"; a.title = "Ghi chú mới (nhấn giữ/chuột phải vào tên để xóa)";
  a.onclick = () => { S.notes.push({ text: "" }); S.cur = S.notes.length - 1; save(); load(); ta.focus(); };
  nl.append(a);
}
function load() { ta.value = S.notes[S.cur].text; $("ttl").value = S.notes[S.cur].title || ""; drawList(); runNote(); }
$("ttl").addEventListener("input", e => { S.notes[S.cur].title = e.target.value; save(); drawList(); });
ta.addEventListener("input", () => { S.notes[S.cur].text = ta.value; save(); runNote(); drawList(); });
ta.addEventListener("scroll", () => out.scrollTop = ta.scrollTop);
out.addEventListener("click", e => {
  const i = Math.floor((e.offsetY + out.scrollTop) / 32), r = results[i];
  if (r && navigator.clipboard) navigator.clipboard.writeText(r.replace(/,/g, "")).catch(() => {});
});

/* Tải / mở .txt */
async function saveFile(name, text) {
  try { if (window.claude && claude.use) { const d = await claude.use("downloads"); if (d) { await d.save({ filename: name, data: text }); return; } } }
  catch (e) { if (e && e.code === "declined") return; }
  const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" })); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
function noteTxt() {
  const L = ta.value.split("\n"), clean = l => l.replace(/=\s*$/, "").trimEnd(), w = Math.max(0, ...L.map((l, i) => results[i] ? clean(l).length : 0));
  return L.map((l, i) => results[i] ? clean(l).padEnd(w) + "  =  " + results[i] : l).join("\n");
}
const title = () => (nameOf(S.notes[S.cur]).replace(/[\\/:*?"<>|]/g, "").trim().slice(0, 40) || "ghi-chu");
$("dlBtn").onclick = () => saveFile(title() + ".txt", noteTxt());
$("openBtn").onclick = () => $("fileIn").click();
$("fileIn").onchange = async e => { const f = e.target.files[0]; if (!f) return; S.notes.push({ text: (await f.text()).slice(0, 200000) }); S.cur = S.notes.length - 1; save(); load(); e.target.value = ""; };
$("delBtn").onclick = () => { if (!confirm("Xóa ghi chú này?")) return; if (S.notes.length > 1) { S.notes.splice(S.cur, 1); S.cur = 0; } else S.notes[0].text = ""; save(); load(); };

/* ===== Tab Máy tính (bàn phím kiểu iPhone) ===== */
const SCI = [["sin","sin("],["cos","cos("],["tan","tan("],["√","sqrt("],["xʸ","^"],["sin⁻¹","asin("],["cos⁻¹","acos("],["tan⁻¹","atan("],["log","log("],["ln","ln("],
 ["(","("],[")",")"],["π","pi"],["e","e"],["n!","!"],["x²","^2"],["x³","^3"],["abs","abs("],["exp","exp("],["Ans","ans"],["1/x","1/("]];
const KEYS = [["AC","@c","u"],["±","@s","u"],["%","%","u"],["÷","/","o"],["7","7"],["8","8"],["9","9"],["×","*","o"],["4","4"],["5","5"],["6","6"],["−","-","o"],
 ["1","1"],["2","2"],["3","3"],["+","+","o"],["0","0","wide"],[".","."],["=","@e","o"]];
let ex = "", ans = 0;
function mk(parent, list) { list.forEach(([label, v, c]) => { const b = document.createElement("button"); b.className = "k " + (c || ""); b.textContent = label; b.onclick = () => key(v); parent.append(b); }); }
mk($("sci"), SCI); mk($("pad"), KEYS);
$("sciBtn").onclick = () => $("sci").classList.toggle("on"); $("bsBtn").onclick = () => key("@b");
function show() {
  $("expr").textContent = ex || "0";
  try { $("res").textContent = ex ? fmt(evaluate(ex, { ans })) : "0"; } catch (e) { $("res").textContent = /hạn|xác định/.test(e.message) ? e.message : "…"; }
}
function key(v) {
  if (v === "@c") ex = ""; else if (v === "@b") ex = ex.slice(0, -1);
  else if (v === "@s") ex = ex ? "-(" + ex + ")" : "-";
  else if (v === "@e") { try { ans = evaluate(ex, { ans }); ex = String(+ans.toPrecision(12)); } catch (e) { $("res").textContent = e.message; return; } }
  else ex += v;
  show();
}
document.addEventListener("keydown", e => {
  if (!$("calc").classList.contains("on") || e.ctrlKey || e.metaKey) return;
  if (/^[\d.+\-*\/^()%!]$/.test(e.key)) key(e.key); else if (e.key === "Enter" || e.key === "=") { e.preventDefault(); key("@e"); }
  else if (e.key === "Backspace") key("@b"); else if (e.key === "Escape") key("@c");
});

/* ===== Giao diện ===== */
$("tabs").addEventListener("click", e => {
  const t = e.target.dataset.tab; if (!t) return;
  document.querySelectorAll("#tabs button").forEach(b => b.classList.toggle("on", b === e.target));
  document.querySelectorAll(".view").forEach(v => v.classList.toggle("on", v.id === t));
});
$("modeBtn").onclick = e => { deg = !deg; e.target.textContent = deg ? "DEG" : "RAD"; runNote(); show(); };
$("themeBtn").onclick = () => document.body.classList.toggle("light");

document.addEventListener("pointermove", e => {
  const g = e.target.closest && e.target.closest(".glass"); if (!g) return;
  const r = g.getBoundingClientRect(); g.style.setProperty("--mx", (e.clientX - r.left) + "px"); g.style.setProperty("--my", (e.clientY - r.top) + "px");
});
load(); show();
window.UnknownCalc = { evaluate, setDeg: v => deg = v };  // để kiểm thử
})();
