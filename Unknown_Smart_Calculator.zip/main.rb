# May tinh Ruby. Nhap: 12 * 3 | 7 % 3 | 2 ^ 10 | sqrt 81 | q de thoat
loop do
  print "> "
  line = gets or break
  p = line.split
  break if p == ["q"]
  begin
    r = if p.size == 2 && p[0] == "sqrt" then Math.sqrt(Float(p[1]))
        elsif p.size == 3
          a, b = Float(p[0]), Float(p[2])
          case p[1]
          when "+" then a + b
          when "-" then a - b
          when "*" then a * b
          when "/" then raise "Chia cho 0" if b == 0; a / b
          when "%" then a % b
          when "^" then a**b
          else raise "Toan tu khong ho tro"
          end
        else raise "Cu phap: a op b | sqrt a" end
    puts "= #{r.round(10)}"
  rescue => e
    puts "Loi: #{e.message}"
  end
end
