BTW May tinh LOLCODE: nhap a, toan tu (+ - * / %), b
HAI 1.2
  I HAS A a
  I HAS A op
  I HAS A b
  VISIBLE "Nhap so a: " !
  GIMMEH a
  VISIBLE "Nhap toan tu (+ - * / %): " !
  GIMMEH op
  VISIBLE "Nhap so b: " !
  GIMMEH b
  a IS NOW A NUMBAR
  b IS NOW A NUMBAR
  op, WTF?
    OMG "+"
      VISIBLE "= " SUM OF a AN b
      GTFO
    OMG "-"
      VISIBLE "= " DIFF OF a AN b
      GTFO
    OMG "*"
      VISIBLE "= " PRODUKT OF a AN b
      GTFO
    OMG "/"
      BOTH SAEM b AN 0
      O RLY?
        YA RLY
          VISIBLE "Loi: chia cho 0"
        NO WAI
          VISIBLE "= " QUOSHUNT OF a AN b
      OIC
      GTFO
    OMG "%"
      VISIBLE "= " MOD OF a AN b
      GTFO
    OMGWTF
      VISIBLE "Toan tu khong ho tro"
  OIC
KTHXBYE
