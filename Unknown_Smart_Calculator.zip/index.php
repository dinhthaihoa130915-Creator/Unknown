<?php
// May tinh PHP. Chay: php index.php   (nhap: 12 * 3 | 7 % 3 | 2 ^ 10 | sqrt 81 | q)
// Hoac:    php index.php "12 * 3"
function calc(string $line): string {
    $p = preg_split('/\s+/', trim($line));
    if (count($p) === 2 && $p[0] === 'sqrt' && is_numeric($p[1])) return (string)sqrt((float)$p[1]);
    if (count($p) !== 3 || !is_numeric($p[0]) || !is_numeric($p[2])) return 'Cu phap: a op b | sqrt a';
    [$a, $op, $b] = [(float)$p[0], $p[1], (float)$p[2]];
    switch ($op) {
        case '+': return (string)($a + $b);
        case '-': return (string)($a - $b);
        case '*': return (string)($a * $b);
        case '/': return $b == 0 ? 'Loi: chia cho 0' : (string)($a / $b);
        case '%': return $b == 0 ? 'Loi: chia cho 0' : (string)fmod($a, $b);
        case '^': return (string)pow($a, $b);
    }
    return 'Toan tu khong ho tro';
}
if (isset($argv[1])) { echo '= ', calc(implode(' ', array_slice($argv, 1))), PHP_EOL; exit; }
while (true) {
    echo '> ';
    $l = fgets(STDIN);
    if ($l === false || trim($l) === 'q') break;
    echo '= ', calc($l), PHP_EOL;
}
