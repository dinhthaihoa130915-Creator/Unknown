// May tinh Swift. Nhap: 12 * 3 | 7 % 3 | 2 ^ 10 | sqrt 81 | q de thoat
import Foundation
while true {
  print("> ", terminator: "")
  guard let line = readLine(), line != "q" else { break }
  let p = line.split(separator: " ").map(String.init)
  var r: Double? = nil
  if p.count == 2, p[0] == "sqrt", let a = Double(p[1]) { r = sqrt(a) }
  else if p.count == 3, let a = Double(p[0]), let b = Double(p[2]) {
    switch p[1] {
    case "+": r = a + b
    case "-": r = a - b
    case "*": r = a * b
    case "/": if b == 0 { print("Loi: chia cho 0"); continue }; r = a / b
    case "%": r = fmod(a, b)
    case "^": r = pow(a, b)
    default: print("Toan tu khong ho tro"); continue
    }
  } else { print("Cu phap: a op b | sqrt a"); continue }
  if let v = r, v.isFinite { print("= \(v)") } else { print("Ket qua khong xac dinh") }
}
