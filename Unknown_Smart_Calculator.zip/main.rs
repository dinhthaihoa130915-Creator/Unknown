// May tinh Rust. Nhap: 12 * 3 | 7 % 3 | 2 ^ 10 | sqrt 81 | q de thoat
use std::io::{self, Write};
fn calc(p: &[&str]) -> Result<f64, String> {
    let n = |s: &str| s.parse::<f64>().map_err(|_| "So khong hop le".to_string());
    match p {
        ["sqrt", x] => Ok(n(x)?.sqrt()),
        [a, op, b] => {
            let (a, b) = (n(a)?, n(b)?);
            match *op {
                "+" => Ok(a + b), "-" => Ok(a - b), "*" => Ok(a * b),
                "/" => if b == 0.0 { Err("Chia cho 0".into()) } else { Ok(a / b) },
                "%" => Ok(a % b), "^" => Ok(a.powf(b)),
                _ => Err("Toan tu khong ho tro".into()),
            }
        }
        _ => Err("Cu phap: a op b | sqrt a".into()),
    }
}
fn main() {
    let mut line = String::new();
    loop {
        print!("> "); io::stdout().flush().ok(); line.clear();
        if io::stdin().read_line(&mut line).unwrap_or(0) == 0 || line.trim() == "q" { break; }
        let p: Vec<&str> = line.split_whitespace().collect();
        match calc(&p) {
            Ok(r) if r.is_finite() => println!("= {}", r),
            Ok(_) => println!("Ket qua khong xac dinh"),
            Err(e) => println!("Loi: {}", e),
        }
    }
}
