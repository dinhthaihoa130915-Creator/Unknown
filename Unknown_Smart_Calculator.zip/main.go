// May tinh Go. Nhap: 12 * 3 | 7 % 3 | 2 ^ 10 | sqrt 81 | q de thoat
package main

import ("bufio";"fmt";"math";"os";"strconv";"strings")

func main() {
	sc := bufio.NewScanner(os.Stdin)
	for fmt.Print("> "); sc.Scan(); fmt.Print("> ") {
		p := strings.Fields(sc.Text())
		if len(p) == 1 && p[0] == "q" { return }
		var r float64
		if len(p) == 2 && p[0] == "sqrt" {
			a, e := strconv.ParseFloat(p[1], 64); if e != nil { fmt.Println("So khong hop le"); continue }
			r = math.Sqrt(a)
		} else if len(p) == 3 {
			a, e1 := strconv.ParseFloat(p[0], 64); b, e2 := strconv.ParseFloat(p[2], 64)
			if e1 != nil || e2 != nil { fmt.Println("So khong hop le"); continue }
			switch p[1] {
			case "+": r = a + b
			case "-": r = a - b
			case "*": r = a * b
			case "/": if b == 0 { fmt.Println("Loi: chia cho 0"); continue }; r = a / b
			case "%": r = math.Mod(a, b)
			case "^": r = math.Pow(a, b)
			default: fmt.Println("Toan tu khong ho tro"); continue
			}
		} else { fmt.Println("Cu phap: a op b | sqrt a"); continue }
		if math.IsNaN(r) || math.IsInf(r, 0) { fmt.Println("Ket qua khong xac dinh"); continue }
		fmt.Println("=", strconv.FormatFloat(r, 'g', 12, 64))
	}
}
