// Máy tính dòng lệnh: cargo run --bin calc
// Gõ biểu thức, ví dụ: Lương = 15000000 | Lương * 12 | 100 + 10% | 9⁹ | sin(30) | ans * 2
// Lệnh: deg / rad / q (thoát)
use std::io::{self, Write};
use unknown_calc::{fmt, Calc};

fn main() {
    let mut calc = Calc::new();
    let stdin = io::stdin();
    let mut line = String::new();
    loop {
        print!("> ");
        io::stdout().flush().ok();
        line.clear();
        if stdin.read_line(&mut line).unwrap_or(0) == 0 {
            break;
        }
        let cmd = line.trim().to_lowercase();
        match cmd.as_str() {
            "q" => break,
            "deg" => {
                calc.deg = true;
                println!("Chế độ DEG");
            }
            "rad" => {
                calc.deg = false;
                println!("Chế độ RAD");
            }
            _ => match calc.run_line(&line) {
                Some(Ok(v)) => println!("= {}", fmt(v)),
                Some(Err(e)) => println!("Lỗi: {}", e),
                None => {}
            },
        }
    }
}
