//! Engine tính toán: biểu thức, biến (kể cả tên nhiều chữ), hàm, %, giai thừa,
//! số mũ Unicode (9⁹), nhân ngầm (2π, 2(3+4)), ans, DEG/RAD.
//! Cùng quy tắc với bản web (index.js).

use std::collections::HashMap;
use std::f64::consts::{E, PI, TAU};

#[derive(Debug, Clone, PartialEq)]
enum Tok {
    Num(f64),
    Id(String),
    Op(char),
}

const FUNCS: [&str; 19] = [
    "sin", "cos", "tan", "asin", "acos", "atan", "sqrt", "cbrt", "log", "ln", "abs", "exp", "floor", "ceil", "round",
    "min", "max", "pow", "mod",
];

fn is_fn(name: &str) -> bool {
    name == "fact" || FUNCS.contains(&name)
}

fn sup_char(c: char) -> Option<char> {
    match c {
        '⁰' => Some('0'),
        '¹' => Some('1'),
        '²' => Some('2'),
        '³' => Some('3'),
        '⁴' => Some('4'),
        '⁵' => Some('5'),
        '⁶' => Some('6'),
        '⁷' => Some('7'),
        '⁸' => Some('8'),
        '⁹' => Some('9'),
        '⁻' => Some('-'),
        _ => None,
    }
}

/// Đổi ×, ÷, −, π, √ và chữ số mũ (9⁹ -> 9^(9)) về ký tự thường.
fn preprocess(s: &str) -> String {
    let mut out = String::new();
    let mut sup = String::new();
    for c in s.chars() {
        if let Some(d) = sup_char(c) {
            sup.push(d);
            continue;
        }
        if !sup.is_empty() {
            out.push_str(&format!("^({})", sup));
            sup.clear();
        }
        match c {
            '×' => out.push('*'),
            '÷' => out.push('/'),
            '−' => out.push('-'),
            'π' => out.push_str("pi"),
            '√' => out.push_str("sqrt"),
            _ => out.push(c),
        }
    }
    if !sup.is_empty() {
        out.push_str(&format!("^({})", sup));
    }
    out
}

fn tokenize(s: &str) -> Result<Vec<Tok>, String> {
    let ch: Vec<char> = preprocess(s).chars().collect();
    let mut i = 0;
    let mut raw: Vec<Tok> = Vec::new();
    while i < ch.len() {
        let c = ch[i];
        if c.is_whitespace() {
            i += 1;
        } else if c.is_ascii_digit() || c == '.' {
            let st = i;
            while i < ch.len() && (ch[i].is_ascii_digit() || ch[i] == '.') {
                i += 1;
            }
            if i < ch.len() && (ch[i] == 'e' || ch[i] == 'E') {
                let mut j = i + 1;
                if j < ch.len() && (ch[j] == '+' || ch[j] == '-') {
                    j += 1;
                }
                if j < ch.len() && ch[j].is_ascii_digit() {
                    while j < ch.len() && ch[j].is_ascii_digit() {
                        j += 1;
                    }
                    i = j;
                }
            }
            let t: String = ch[st..i].iter().collect();
            let v = t.parse::<f64>().map_err(|_| format!("Số sai: {}", t))?;
            raw.push(Tok::Num(v));
        } else if c.is_alphabetic() || c == '_' {
            let st = i;
            while i < ch.len() && (ch[i].is_alphanumeric() || ch[i] == '_') {
                i += 1;
            }
            let name: String = ch[st..i].iter().collect();
            raw.push(Tok::Id(name.to_lowercase()));
        } else if "+-*/^()%!,".contains(c) {
            raw.push(Tok::Op(c));
            i += 1;
        } else {
            return Err("Ký tự không hợp lệ".to_string());
        }
    }
    // nhân ngầm: 2pi, 2(3+4), (1+2)(3+4)
    let mut res: Vec<Tok> = Vec::new();
    for t in raw {
        let need_mul = {
            let prev_end = match res.last() {
                Some(Tok::Num(_)) => true,
                Some(Tok::Id(n)) => !is_fn(n),
                Some(Tok::Op(')')) | Some(Tok::Op('!')) | Some(Tok::Op('%')) => true,
                _ => false,
            };
            let cur_start = matches!(t, Tok::Num(_) | Tok::Id(_) | Tok::Op('('));
            prev_end && cur_start
        };
        if need_mul {
            res.push(Tok::Op('*'));
        }
        res.push(t);
    }
    Ok(res)
}

fn fact(x: f64) -> Result<f64, String> {
    if x < 0.0 || x.fract() != 0.0 || x > 170.0 {
        return Err("fact: chỉ nhận số nguyên từ 0 đến 170".to_string());
    }
    let mut r = 1.0;
    let mut i = 2.0;
    while i <= x {
        r *= i;
        i += 1.0;
    }
    Ok(r)
}

struct Parser<'a> {
    t: Vec<Tok>,
    p: usize,
    pct: bool,
    deg: bool,
    vars: &'a HashMap<String, f64>,
}

impl<'a> Parser<'a> {
    fn is_op(&self, c: char) -> bool {
        matches!(self.t.get(self.p), Some(Tok::Op(x)) if *x == c)
    }

    fn need(&mut self, c: char) -> Result<(), String> {
        if self.is_op(c) {
            self.p += 1;
            Ok(())
        } else {
            Err(format!("Thiếu {}", c))
        }
    }

    fn call(&self, name: &str, a: &[f64]) -> Result<f64, String> {
        let x = a.first().copied().ok_or_else(|| "Thiếu đối số".to_string())?;
        let to_rad = |v: f64| if self.deg { v.to_radians() } else { v };
        let from_rad = |v: f64| if self.deg { v.to_degrees() } else { v };
        match name {
            "sin" => Ok(to_rad(x).sin()),
            "cos" => Ok(to_rad(x).cos()),
            "tan" => Ok(to_rad(x).tan()),
            "asin" => Ok(from_rad(x.asin())),
            "acos" => Ok(from_rad(x.acos())),
            "atan" => Ok(from_rad(x.atan())),
            "sqrt" => Ok(x.sqrt()),
            "cbrt" => Ok(x.cbrt()),
            "log" => Ok(x.log10()),
            "ln" => Ok(x.ln()),
            "abs" => Ok(x.abs()),
            "exp" => Ok(x.exp()),
            "floor" => Ok(x.floor()),
            "ceil" => Ok(x.ceil()),
            "round" => Ok(x.round()),
            "fact" => fact(x),
            "min" => Ok(a.iter().cloned().fold(f64::INFINITY, f64::min)),
            "max" => Ok(a.iter().cloned().fold(f64::NEG_INFINITY, f64::max)),
            "pow" | "mod" => {
                let y = a.get(1).copied().ok_or_else(|| "Thiếu đối số thứ hai".to_string())?;
                Ok(if name == "pow" { x.powf(y) } else { x % y })
            }
            _ => Err(format!("Chưa biết hàm: {}", name)),
        }
    }

    fn prim(&mut self) -> Result<f64, String> {
        let tok = self.t.get(self.p).cloned();
        self.p += 1;
        match tok {
            None => Err("Chưa hoàn chỉnh".to_string()),
            Some(Tok::Num(v)) => Ok(v),
            Some(Tok::Op('(')) => {
                let x = self.add()?;
                self.need(')')?;
                Ok(x)
            }
            Some(Tok::Id(name)) => {
                if is_fn(&name) {
                    self.need('(')?;
                    let mut args = vec![self.add()?];
                    while self.is_op(',') {
                        self.p += 1;
                        args.push(self.add()?);
                    }
                    self.need(')')?;
                    self.call(&name, &args)
                } else if let Some(v) = self.vars.get(&name) {
                    Ok(*v)
                } else {
                    match name.as_str() {
                        "pi" => Ok(PI),
                        "e" => Ok(E),
                        "tau" => Ok(TAU),
                        _ => Err(format!("Chưa biết: {}", name)),
                    }
                }
            }
            _ => Err("Sai cú pháp".to_string()),
        }
    }

    fn post(&mut self) -> Result<f64, String> {
        let mut x = self.prim()?;
        loop {
            if self.is_op('!') {
                self.p += 1;
                x = fact(x)?;
            } else if self.is_op('%') {
                self.p += 1;
                x /= 100.0;
                self.pct = true;
            } else {
                break;
            }
        }
        Ok(x)
    }

    fn pow(&mut self) -> Result<f64, String> {
        let x = self.post()?;
        if self.is_op('^') {
            self.p += 1;
            self.pct = false;
            let y = self.unary()?;
            return Ok(x.powf(y));
        }
        Ok(x)
    }

    fn unary(&mut self) -> Result<f64, String> {
        if self.is_op('-') {
            self.p += 1;
            return Ok(-self.unary()?);
        }
        if self.is_op('+') {
            self.p += 1;
            return self.unary();
        }
        self.pow()
    }

    fn mul(&mut self) -> Result<f64, String> {
        let mut x = self.unary()?;
        loop {
            let is_mul = self.is_op('*');
            let is_div = self.is_op('/');
            if !is_mul && !is_div {
                break;
            }
            self.p += 1;
            let y = self.unary()?;
            self.pct = false;
            x = if is_mul { x * y } else { x / y };
        }
        Ok(x)
    }

    fn add(&mut self) -> Result<f64, String> {
        let mut x = self.mul()?;
        loop {
            let plus = self.is_op('+');
            let minus = self.is_op('-');
            if !plus && !minus {
                break;
            }
            self.p += 1;
            self.pct = false;
            let mut y = self.mul()?;
            if self.pct {
                y = x * y; // 100 + 10% = 110 (giống iPhone)
            }
            x = if plus { x + y } else { x - y };
        }
        Ok(x)
    }
}

/// Định dạng số: nhóm hàng nghìn, tối đa 10 số lẻ, dạng khoa học khi quá lớn/nhỏ.
pub fn fmt(n: f64) -> String {
    let n = if n == 0.0 { 0.0 } else { n };
    if n.abs() >= 1e15 || (n != 0.0 && n.abs() < 1e-9) {
        return format!("{:e}", n);
    }
    let s = format!("{:.10}", n);
    let s = s.trim_end_matches('0').trim_end_matches('.').to_string();
    let (neg, body) = match s.strip_prefix('-') {
        Some(b) => (true, b.to_string()),
        None => (false, s.clone()),
    };
    let (int_part, frac) = match body.split_once('.') {
        Some((a, b)) => (a.to_string(), format!(".{}", b)),
        None => (body.clone(), String::new()),
    };
    let mut grouped = String::new();
    let len = int_part.len();
    for (i, c) in int_part.chars().enumerate() {
        if i > 0 && (len - i) % 3 == 0 {
            grouped.push(',');
        }
        grouped.push(c);
    }
    format!("{}{}{}", if neg { "-" } else { "" }, grouped, frac)
}

fn valid_name(s: &str) -> bool {
    let mut it = s.chars();
    match it.next() {
        Some(c) if c.is_alphabetic() || c == '_' => it.all(|c| c.is_alphanumeric() || c == '_' || c == ' '),
        _ => false,
    }
}

fn match_at(ch: &[char], start: usize, words: &[&str]) -> Option<usize> {
    let mut i = start;
    for (wi, w) in words.iter().enumerate() {
        if wi > 0 {
            let st = i;
            while i < ch.len() && ch[i].is_whitespace() {
                i += 1;
            }
            if i == st {
                return None;
            }
        }
        for wc in w.chars() {
            if i >= ch.len() || ch[i].to_lowercase().next() != Some(wc) {
                return None;
            }
            i += 1;
        }
    }
    if i < ch.len() && (ch[i].is_alphanumeric() || ch[i] == '_') {
        return None;
    }
    Some(i)
}

/// Biến nhiều chữ ("thuê nhà") -> "thuê_nhà" trước khi tính.
fn subst(expr: &str, keys: &[String]) -> String {
    let ch: Vec<char> = expr.chars().collect();
    let mut out = String::new();
    let mut i = 0;
    'outer: while i < ch.len() {
        let before_ok = i == 0 || !(ch[i - 1].is_alphanumeric() || ch[i - 1] == '_');
        if before_ok {
            for k in keys {
                let words: Vec<&str> = k.split('_').collect();
                if let Some(e) = match_at(&ch, i, &words) {
                    out.push_str(k);
                    i = e;
                    continue 'outer;
                }
            }
        }
        out.push(ch[i]);
        i += 1;
    }
    out
}

pub struct Calc {
    pub vars: HashMap<String, f64>,
    pub deg: bool,
}

impl Default for Calc {
    fn default() -> Self {
        Calc::new()
    }
}

impl Calc {
    pub fn new() -> Calc {
        let mut vars = HashMap::new();
        vars.insert("ans".to_string(), 0.0);
        Calc { vars, deg: true }
    }

    /// Tính một biểu thức (không gán biến).
    pub fn eval(&self, expr: &str) -> Result<f64, String> {
        let toks = tokenize(expr)?;
        if toks.is_empty() {
            return Err("Trống".to_string());
        }
        let mut p = Parser { t: toks, p: 0, pct: false, deg: self.deg, vars: &self.vars };
        let v = p.add()?;
        if p.p != p.t.len() {
            return Err("Thừa ký tự".to_string());
        }
        if v == f64::INFINITY {
            Err("Vô hạn".to_string())
        } else if v == f64::NEG_INFINITY {
            Err("-Vô hạn".to_string())
        } else if v.is_nan() {
            Err("Không xác định".to_string())
        } else {
            Ok(v)
        }
    }

    /// Xử lý một dòng ghi chú như bản web:
    /// `tên = biểu thức` tạo biến, `#`/`//` là chú thích, dòng chữ thường bị bỏ qua (None).
    pub fn run_line(&mut self, line: &str) -> Option<Result<f64, String>> {
        let mut l = line.trim().to_string();
        if l.is_empty() || l.starts_with('#') || l.starts_with("//") {
            return None;
        }
        let explicit = l.ends_with('=');
        if explicit {
            l = l.trim_end_matches('=').trim_end().to_string();
        }
        let (name, expr): (Option<String>, String) = match l.find('=') {
            Some(i) if valid_name(l[..i].trim()) => {
                let n = l[..i].trim().to_lowercase().split_whitespace().collect::<Vec<&str>>().join("_");
                (Some(n), l[i + 1..].trim().to_string())
            }
            _ => (None, l.clone()),
        };
        let mut keys: Vec<String> = self.vars.keys().filter(|k| k.contains('_')).cloned().collect();
        keys.sort_by(|a, b| b.len().cmp(&a.len()));
        let text = subst(&expr, &keys);
        match self.eval(&text) {
            Ok(v) => {
                if let Some(n) = name {
                    self.vars.insert(n, v);
                }
                self.vars.insert("ans".to_string(), v);
                Some(Ok(v))
            }
            Err(e) => {
                let mathy = l.chars().next().map_or(false, |c| c.is_ascii_digit() || c == '(' || c == '.');
                if explicit || mathy {
                    Some(Err(e))
                } else {
                    None
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ev(s: &str) -> f64 {
        Calc::new().eval(s).unwrap()
    }

    fn near(a: f64, b: f64) -> bool {
        (a - b).abs() <= 1e-9 * b.abs().max(1.0)
    }

    #[test]
    fn co_ban() {
        assert!(near(ev("sqrt(81)+2^3"), 17.0));
        assert!(near(ev("5!"), 120.0));
        assert!(near(ev("2(3+4)"), 14.0));
        assert!(near(ev("-2^2"), -4.0));
        assert!(near(ev("max(3,9,4)"), 9.0));
        assert!(near(ev("sin(30)"), 0.5));
    }

    #[test]
    fn phan_tram_kieu_iphone() {
        assert!(near(ev("100+10%"), 110.0));
        assert!(near(ev("200-50%"), 100.0));
        assert!(near(ev("10+50%*2"), 11.0));
    }

    #[test]
    fn so_mu_unicode() {
        assert!(near(ev("9⁹"), 387420489.0));
        assert!(near(ev("2³+1"), 9.0));
        assert!(near(ev("10⁻²"), 0.01));
    }

    #[test]
    fn vo_han() {
        assert_eq!(Calc::new().eval("10^400"), Err("Vô hạn".to_string()));
        assert_eq!(Calc::new().eval("1/0"), Err("Vô hạn".to_string()));
        assert_eq!(Calc::new().eval("sqrt(-1)"), Err("Không xác định".to_string()));
    }

    #[test]
    fn bien_nhieu_chu() {
        let mut c = Calc::new();
        c.run_line("Lương = 15000000");
        c.run_line("Thuê nhà = 4500000");
        c.run_line("Ăn uống = 3 * 1200000");
        let r = c.run_line("Lương - Thuê nhà - Ăn uống").unwrap().unwrap();
        assert_eq!(fmt(r), "6,900,000");
    }

    #[test]
    fn dinh_dang() {
        assert_eq!(fmt(180000000.0), "180,000,000");
        assert_eq!(fmt(0.1 + 0.2), "0.3");
        assert_eq!(fmt(-1234.5), "-1,234.5");
    }
}
