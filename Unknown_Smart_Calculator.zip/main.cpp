// May tinh C++. Nhap: 12 * 3 | 7 % 3 | 2 ^ 10 | sqrt 81 | q de thoat
#include <iostream>
#include <sstream>
#include <cmath>
#include <iomanip>
int main(){std::string l;
 while(std::cout<<"> "&&std::getline(std::cin,l)&&l!="q"){std::istringstream s(l);std::string t;s>>t;double a,b,r;char o;
  if(t=="sqrt"&&(s>>a))r=std::sqrt(a);
  else{std::istringstream u(l);if(!(u>>a>>o>>b)){std::cout<<"Cu phap: a op b | sqrt a\n";continue;}
   switch(o){case'+':r=a+b;break;case'-':r=a-b;break;case'*':r=a*b;break;
    case'/':if(b==0){std::cout<<"Loi: chia cho 0\n";continue;}r=a/b;break;
    case'%':r=std::fmod(a,b);break;case'^':r=std::pow(a,b);break;default:std::cout<<"Toan tu khong ho tro\n";continue;}}
  if(std::isfinite(r))std::cout<<"= "<<std::setprecision(12)<<r<<"\n";else std::cout<<"Ket qua khong xac dinh\n";}}
