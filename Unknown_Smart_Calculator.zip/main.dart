// May tinh Dart (dart run main.dart). Nhap: 12 * 3 | 7 % 3 | 2 ^ 10 | sqrt 81 | q
import 'dart:io';
import 'dart:math';
String calc(String line) {
  final p = line.trim().split(RegExp(r'\s+'));
  double r;
  if (p.length == 2 && p[0] == 'sqrt' && double.tryParse(p[1]) != null) {
    r = sqrt(double.parse(p[1]));
  } else if (p.length == 3 && double.tryParse(p[0]) != null && double.tryParse(p[2]) != null) {
    final a = double.parse(p[0]), b = double.parse(p[2]);
    switch (p[1]) {
      case '+': r = a + b; break;
      case '-': r = a - b; break;
      case '*': r = a * b; break;
      case '/': if (b == 0) return 'Loi: chia cho 0'; r = a / b; break;
      case '%': if (b == 0) return 'Loi: chia cho 0'; r = a % b; break;
      case '^': r = pow(a, b).toDouble(); break;
      default: return 'Toan tu khong ho tro';
    }
  } else {
    return 'Cu phap: a op b | sqrt a';
  }
  return r.isFinite ? '= ${double.parse(r.toStringAsPrecision(12))}' : 'Ket qua khong xac dinh';
}
void main() {
  while (true) {
    stdout.write('> ');
    final l = stdin.readLineSync();
    if (l == null || l.trim() == 'q') break;
    print(calc(l));
  }
}
