"""May tinh khoa hoc dong lenh (an toan, khong dung eval).
Chay: python main.py "sqrt(81)+2^3"   hoac   python main.py   (che do nhieu dong, co bien)
Vi du: luong = 15000000 | luong * 12 | 100 + 10% | 5! | sin(30) | ans * 2 | deg/rad | q"""
import ast, math, operator as op, re, sys
OPS = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv, ast.Pow: op.pow, ast.Mod: op.mod, ast.USub: op.neg, ast.UAdd: op.pos}
state = {"deg": True, "vars": {"pi": math.pi, "e": math.e, "ans": 0.0}}
class Pct(float): pass   # "N%" - cong/tru theo phan tram cua so ben trai (giong iPhone)
def trig(f): return lambda x: f(math.radians(x) if state["deg"] else x)
def atrig(f): return lambda x: math.degrees(f(x)) if state["deg"] else f(x)
FUNCS = {"sin": trig(math.sin), "cos": trig(math.cos), "tan": trig(math.tan), "asin": atrig(math.asin), "acos": atrig(math.acos), "atan": atrig(math.atan),
         "sqrt": math.sqrt, "cbrt": lambda x: math.copysign(abs(x) ** (1/3), x), "log": math.log10, "ln": math.log, "abs": abs, "exp": math.exp,
         "floor": math.floor, "ceil": math.ceil, "round": round, "fact": math.factorial, "min": min, "max": max, "pow": pow, "pct": Pct}
def prep(s):
    s = s.replace("^", "**").replace("π", "pi").replace("×", "*").replace("÷", "/").replace("√", "sqrt")
    s = re.sub(r"(\d+(?:\.\d+)?)!", r"fact(\1)", s)                                      # 5! -> fact(5)
    while ")!" in s:                                                                         # (2+3)! -> fact((2+3))
        j = s.index(")!"); d = 0
        for i in range(j, -1, -1):
            d += (s[i] == ")") - (s[i] == "(")
            if d == 0: break
        s = s[:i] + "fact(" + s[i:j+1] + ")" + s[j+2:]
    s = re.sub(r"(\d+(?:\.\d+)?)%(?!\s*[\d(a-zA-Z_.])", r"pct(\1/100)", s)                    # 10% -> pct(0.1)
    s = re.sub(r"(\d|\))\s*(?=[a-zA-Z_(])", r"\1*", s)                                        # 2pi, 2(3+4)
    return s
def calculate(expr):
    def run(n):
        if isinstance(n, ast.Expression): return run(n.body)
        if isinstance(n, ast.Constant) and type(n.value) in (int, float): return n.value
        if isinstance(n, ast.Name) and n.id.lower() in state["vars"]: return state["vars"][n.id.lower()]
        if isinstance(n, ast.BinOp) and type(n.op) in OPS:
            l, r = run(n.left), run(n.right)
            if isinstance(r, Pct) and isinstance(n.op, (ast.Add, ast.Sub)): r = l * r
            return OPS[type(n.op)](l, r)
        if isinstance(n, ast.UnaryOp) and type(n.op) in OPS: return OPS[type(n.op)](run(n.operand))
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in FUNCS and not n.keywords: return FUNCS[n.func.id](*map(run, n.args))
        raise ValueError("Bieu thuc hoac ham khong duoc ho tro")
    r = run(ast.parse(prep(expr).strip(), mode="eval"))
    if isinstance(r, complex) or not math.isfinite(r): raise ValueError("Ket qua khong xac dinh")
    return r
def handle(line):
    line = line.strip()
    if line.lower() in ("deg", "rad"): state["deg"] = line.lower() == "deg"; return f"Che do {line.upper()}"
    m = re.match(r"^([A-Za-z_]\w*)\s*=\s*(.+)$", line)
    r = calculate(m.group(2) if m else line)
    if m: state["vars"][m.group(1).lower()] = r
    state["vars"]["ans"] = r
    return "= " + format(r, ".12g")
if __name__ == "__main__":
    if len(sys.argv) > 1:
        try: print(handle(" ".join(sys.argv[1:])))
        except Exception as e: print("Loi:", e)
    else:
        while True:
            try: line = input("> ")
            except EOFError: break
            if line.strip() == "q": break
            if line.strip():
                try: print(handle(line))
                except ZeroDivisionError: print("Loi: chia cho 0")
                except Exception as e: print("Loi:", e)
