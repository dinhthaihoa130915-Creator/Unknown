/* May tinh C. Nhap: "12 * 3" | "7 % 3" | "2 ^ 10" | "sqrt 81" | q de thoat */
#include <stdio.h>
#include <math.h>
#include <string.h>
int main(void){char l[128],o;double a,b,r;
 for(;;){printf("> ");if(!fgets(l,sizeof l,stdin)||l[0]=='q')return 0;
  if(sscanf(l,"sqrt %lf",&a)==1)r=sqrt(a);
  else if(sscanf(l,"%lf %c %lf",&a,&o,&b)==3){
   switch(o){case'+':r=a+b;break;case'-':r=a-b;break;case'*':r=a*b;break;
    case'/':if(b==0){puts("Loi: chia cho 0");continue;}r=a/b;break;
    case'%':r=fmod(a,b);break;case'^':r=pow(a,b);break;default:puts("Toan tu khong ho tro");continue;}
  }else{puts("Cu phap: a op b | sqrt a");continue;}
  if(isfinite(r))printf("= %.12g\n",r);else puts("Ket qua khong xac dinh");}}
