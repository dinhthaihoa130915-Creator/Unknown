⍝ May tinh APL (GNU APL): nhap bieu thuc APL, vi du: 12×3   hoac   +/⍳5   hoac   (2*10)-1
⍞←'Nhap bieu thuc: '
⎕←⍎⍞
