#!/usr/bin/env bash
# May tinh Bash (dung awk). Nhap: 12 * 3 | 7 % 3 | 2 ^ 10 | sqrt 81 | q de thoat
while printf '> ' && read -r a op b; do
  [ "$a" = "q" ] && break
  if [ "$a" = "sqrt" ]; then
    awk -v x="$op" 'BEGIN{ if (x !~ /^[0-9.]+$/) print "So khong hop le"; else printf "= %.12g\n", sqrt(x) }'
  elif [[ "$a" =~ ^-?[0-9.]+$ && "$b" =~ ^-?[0-9.]+$ ]]; then
    awk -v a="$a" -v o="$op" -v b="$b" 'BEGIN{
      if (o=="+") r=a+b; else if (o=="-") r=a-b; else if (o=="*") r=a*b;
      else if (o=="/"||o=="%") { if (b==0) { print "Loi: chia cho 0"; exit } r=(o=="/")?a/b:a%b }
      else if (o=="^") r=a^b; else { print "Toan tu khong ho tro"; exit }
      printf "= %.12g\n", r }'
  else echo "Cu phap: a op b | sqrt a"; fi
done
