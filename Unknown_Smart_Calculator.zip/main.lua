-- May tinh Lua. Nhap: 12 * 3 | 7 % 3 | 2 ^ 10 | sqrt 81 | q de thoat
while true do
  io.write("> ")
  local line = io.read("l")
  if not line or line == "q" then break end
  local r
  local x = line:match("^%s*sqrt%s+(%S+)%s*$")
  if x then
    x = tonumber(x); if x then r = math.sqrt(x) end
  else
    local a, op, b = line:match("^%s*(%S+)%s+(%S+)%s+(%S+)%s*$")
    a, b = tonumber(a), tonumber(b)
    if a and b then
      if op == "+" then r = a + b elseif op == "-" then r = a - b elseif op == "*" then r = a * b
      elseif op == "/" then if b == 0 then print("Loi: chia cho 0") else r = a / b end
      elseif op == "%" then r = math.fmod(a, b) elseif op == "^" then r = a ^ b
      else print("Toan tu khong ho tro") end
    else print("Cu phap: a op b | sqrt a") end
  end
  if r then if r ~= r or r == math.huge or r == -math.huge then print("Ket qua khong xac dinh") else print("= " .. string.format("%.12g", r)) end end
end
