// May tinh Kotlin (kotlinc Main.kt -include-runtime -d calc.jar && java -jar calc.jar). Nhap: 12 * 3 | 7 % 3 | 2 ^ 10 | sqrt 81 | q
fun calc(line: String): String {
    val p = line.trim().split(Regex("\\s+"))
    val r: Double = when {
        p.size == 2 && p[0] == "sqrt" -> Math.sqrt(p[1].toDoubleOrNull() ?: return "So khong hop le")
        p.size == 3 -> {
            val a = p[0].toDoubleOrNull() ?: return "So khong hop le"
            val b = p[2].toDoubleOrNull() ?: return "So khong hop le"
            when (p[1]) {
                "+" -> a + b; "-" -> a - b; "*" -> a * b
                "/" -> if (b == 0.0) return "Loi: chia cho 0" else a / b
                "%" -> if (b == 0.0) return "Loi: chia cho 0" else a % b
                "^" -> Math.pow(a, b)
                else -> return "Toan tu khong ho tro"
            }
        }
        else -> return "Cu phap: a op b | sqrt a"
    }
    return if (r.isNaN() || r.isInfinite()) "Ket qua khong xac dinh" else "= " + java.math.BigDecimal(r).round(java.math.MathContext(12)).stripTrailingZeros().toPlainString()
}
fun main() {
    while (true) {
        print("> ")
        val l = readLine() ?: break
        if (l.trim() == "q") break
        println(calc(l))
    }
}
