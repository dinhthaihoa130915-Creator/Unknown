UNKNOWN CALCULATOR v2 - Liquid Glass + Ghi chú tính toán + mã nguồn đa ngôn ngữ

1. CHẠY BẢN WEB (index.html + style.css + index.js)
- Giải nén file .zip (bấm giữ/nhấn chuột phải → Giải nén), mở index.html bằng trình duyệt. Không cần Internet.
- Tab "Ghi chú" (giống Math Notes của iPhone): gõ phép tính, kết quả hiện ngay bên phải từng dòng.
    Lương = 15000000      ->  tạo biến (tên tiếng Việt, nhiều chữ như "Thuê nhà" đều dùng được)
    Lương * 12            ->  180,000,000
    100 + 10%             ->  110   (phần trăm tính theo số bên trái, như iPhone)
    sqrt(81) + 2^3        ->  17
    ans * 2               ->  ans = kết quả dòng trước
    # Tiêu đề / // ghi chú ->  dòng chữ thường, không tính
  Chạm vào kết quả để chép. Nhiều ghi chú (nút ＋), tự lưu trong trình duyệt.
  Ô "Tiêu đề" đặt tên ghi chú như iPhone: để trống thì tự lấy dòng đầu tiên làm tên.
  Nút "⬇ Tải .txt" lưu ghi chú kèm kết quả; "Mở .txt" nhập file .txt thành ghi chú mới; "Xóa ghi chú".
- Tab "Máy tính": bàn phím kiểu iPhone (AC ± % ÷ × − +), xem trước kết quả khi gõ; nút "ƒ Khoa học" mở thêm hàng sin/cos/log/√...; hỗ trợ bàn phím máy tính.
- Kết quả vượt giới hạn (hoặc chia cho 0) hiện "Vô hạn"; phép không có nghĩa như sqrt(-1) hiện "Không xác định".
- Hàm: sin cos tan asin acos atan sqrt cbrt log ln abs exp floor ceil round min max pow mod fact; hằng số: pi e tau; giai thừa 5!; DEG/RAD.
- Giao diện Liquid Glass: kính mờ trong suốt, viền sáng, vệt sáng theo con trỏ, nền động, tự đổi sáng/tối theo hệ thống.
  (Khác bản gốc: nút "Lịch sử/Bộ nhớ MC-MR" được thay bằng Ghi chú, biến và ans.)

2. CÁC FILE NGÔN NGỮ (đều là máy tính dòng lệnh dạng vòng lặp, nhập "q" để thoát)
Cú pháp chung: a op b  với op là + - * / % ^   hoặc   sqrt a        ví dụ: 12 * 3 | 2 ^ 10 | sqrt 81
- main.py   : bản đầy đủ nhất - biểu thức, biến, hàm, %, giai thừa, ans, deg/rad. Chạy: python3 main.py  hoặc  python3 main.py "sqrt(81)+2^3"
- main.c / main.cpp : gcc main.c -o calc -lm  |  g++ main.cpp -o calc
- main.go: go run main.go          - Main.java: javac Main.java && java Main
- main.rs: rustc main.rs && ./main - main.swift: swiftc main.swift && ./main
- main.rb: ruby main.rb            - main.lua: lua main.lua
- index.php: php index.php  (hoặc php index.php "12 * 3")
- NEW main.pl (Perl) · calc.sh (Bash) · main.ts (TypeScript) · Main.kt (Kotlin) · Program.cs (C#) · main.dart (Dart)
- calc.lisp : sbcl --script calc.lisp, nhập (+ 1 (* 2 3))       - calc.apl : GNU APL, nhập 12×3 hoặc +/⍳5
- calc.lol  : LOLCODE, nhập a, toán tử, b                        - calc.b   : Brainfuck, nhập 3+4 (1 chữ số, tổng <= 9)
- calc.cow  : COW, nhập hai số nguyên -> in tổng
3. DỰ ÁN RUST (thư mục rust/) - engine đầy đủ như bản web
- src/lib.rs   : engine (biểu thức, biến nhiều chữ, hàm, %, giai thừa, số mũ 9⁹, nhân ngầm, ans, Vô hạn) + 6 bài test
- src/main.rs  : máy tính dòng lệnh      -> cd rust && cargo run --bin calc
- src/bin/notes.rs : ghi chú tính toán từ file .txt -> cargo run --bin notes -- ghichu_mau.txt [ketqua.txt]
- Chạy test: cargo test   (cần cài Rust: https://rustup.rs)
- main.rs ở thư mục gốc vẫn là bản đơn giản, biên dịch được bằng: rustc main.rs

4. PHÔNG CHỮ: Rubik Wet Paint (font.woff, đã rút gọn) dùng cho tiêu đề, nút, màn hình máy tính và cột kết quả.
Phông thiếu khoảng 50 chữ tiếng Việt có dấu (ạ, ả, ế, ơ, ư...) nên các chữ đó tự dùng phông hệ thống.

(main.js là bản sao thừa của index.js nên đã được bỏ.)

Rust (cả thư mục rust/) chưa biên dịch được ở máy build (không có rustc) - nếu cargo báo lỗi, gửi lại để sửa.
Đã kiểm thử chạy thật: web engine (Node), Python, C, C++, Perl, Bash, TypeScript, Brainfuck.
Chưa kiểm thử (máy build không có trình biên dịch): Go, Java, Rust, Swift, Ruby, Lua, PHP, Kotlin, C#, Dart, Lisp, APL, LOLCODE, COW.
