// May tinh TypeScript (Deno/Bun/ts-node, hoac: npx tsc main.ts && node main.js). Nhap: 12 * 3 | 7 % 3 | 2 ^ 10 | sqrt 81 | q
import * as readline from "node:readline";
function calc(line: string): string {
  const p = line.trim().split(/\s+/);
  const num = (s: string) => (/^-?\d+(\.\d+)?$/.test(s) ? Number(s) : NaN);
  let r: number;
  if (p.length === 2 && p[0] === "sqrt") r = Math.sqrt(num(p[1]));
  else if (p.length === 3) {
    const a = num(p[0]), b = num(p[2]);
    switch (p[1]) {
      case "+": r = a + b; break; case "-": r = a - b; break; case "*": r = a * b; break;
      case "/": if (b === 0) return "Loi: chia cho 0"; r = a / b; break;
      case "%": if (b === 0) return "Loi: chia cho 0"; r = a % b; break;
      case "^": r = a ** b; break;
      default: return "Toan tu khong ho tro";
    }
  } else return "Cu phap: a op b | sqrt a";
  return Number.isFinite(r) ? "= " + Number(r.toPrecision(12)) : "Ket qua khong xac dinh";
}
const rl = readline.createInterface({ input: process.stdin, output: process.stdout, prompt: "> " });
rl.prompt();
rl.on("line", (l: string) => { if (l.trim() === "q") return rl.close(); console.log(calc(l)); rl.prompt(); });
